find | wc -l
