#!/bin/bash
git rev-list -n 5 HEAD 
