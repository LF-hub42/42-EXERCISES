/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekypraio <ekypraio@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/13 12:30:04 by ekypraio          #+#    #+#             */
/*   Updated: 2025/08/13 16:20:46 by ekypraio         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}

/*#include <stdio.h>
int	main(void)
{
	int		number = 10;
	int		*nbr = &number;
	int		**nbr2 = &nbr;
	int		***nbr3 = &nbr2;
	int		****nbr4 = &nbr3;
	int		*****nbr5 = &nbr4;
	int		******nbr6 = &nbr5;
	int		*******nbr7 = &nbr6;
	int		********nbr8 = &nbr7;

	
	ft_ultimate_ft(&nbr8);
	printf("%d\n", number);
	return (0);
}*/
